function GetData(callback) {
  // make async call and print json to console
  //1. XMLHttpRequest object
  //2. open(httpverb,url)
  //3. onreadystatechange
  //4. send() places the async call

  var xmlhttpReq = new XMLHttpRequest();
  xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlhttpReq.onreadystatechange = function () {
    if (xmlhttpReq.readyState === 4 && xmlhttpReq.status === 200) {
      callback(null, xmlhttpReq.responseText);
    } else if (xmlhttpReq.readyState === 4 && xmlhttpReq.status !== 200) {
      callback("Something went wrong !" + xmlhttpReq.status, null);
    }
  };
  xmlhttpReq.send(); // async
}
