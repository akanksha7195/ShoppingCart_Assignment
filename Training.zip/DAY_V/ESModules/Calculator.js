import Addition, { Product as Multiplication } from "./MathModule.js";
console.log("Addition is : " + Addition(20, 30));
console.log("Multiplication is : " + Multiplication(20, 30));

// import * as MathModule from "./MathModule.js";
// console.log("Addition is : " + MathModule.Add(20, 30));

// import { Add, Product } from "./MathModule.js";
// console.log("Addition is : " + Add(20, 30));
// console.log("Product is : " + Product(20, 30));
